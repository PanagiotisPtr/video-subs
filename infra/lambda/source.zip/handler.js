"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handleS3Event = void 0;
const client_sqs_1 = require("@aws-sdk/client-sqs");
const sqsClient = new client_sqs_1.SQSClient({ region: process.env.AWS_REGION });
const handleS3Event = (event) => __awaiter(void 0, void 0, void 0, function* () {
    console.log("Processing event: ", JSON.stringify(event));
    const queueUrl = process.env.SQS_QUEUE_URL;
    if (!queueUrl) {
        throw new Error('SQS_QUEUE_URL is not set');
    }
    for (const record of event.Records) {
        const s3 = record.s3;
        const bucket = s3.bucket.name;
        const key = s3.object.key;
        const messageBody = JSON.stringify({
            bucket,
            key,
        });
        const params = {
            QueueUrl: queueUrl,
            MessageBody: messageBody,
        };
        try {
            const command = new client_sqs_1.SendMessageCommand(params);
            yield sqsClient.send(command);
            console.log(`Message sent to SQS queue: ${messageBody}`);
        }
        catch (error) {
            console.error(`Error sending message to SQS queue: ${error}`);
            throw error;
        }
    }
});
exports.handleS3Event = handleS3Event;
